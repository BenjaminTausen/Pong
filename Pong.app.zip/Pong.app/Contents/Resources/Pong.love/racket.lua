if collisionBox == false then
	collisionBox = require("collisionBox")
end

racket = {}

racket.rackets = {}

racket.racketDelete = {}

function racket.create(parameters)
	local r = {}
	r.x = parameters.x
	r.y = parameters.y
	r.xSize = parameters.xSize
	r.ySize = parameters.ySize
	r.xVelocity = parameters.xVelocity
	r.yVelocity = parameters.yVelocity
	r.xMaxVelocity = parameters.xMaxVelocity
	r.yMaxVelocity = parameters.yMaxVelocity
	r.friction = parameters.friction
	r.movementSpeed = parameters.movementSpeed
	r.controls = parameters.controls
	r.id = parameters.id
	racket.rackets[#racket.rackets+1] = r
end

function racket.updateAll(dt)
	for i = 1, #racket.rackets do
		racket.update(i, dt)
	end
	-- Iterates through the racket.racketDelete table, and deletes the necessary values
	for j = 1, #racket.racketDelete do
		table.remove(racket.rackets, racket.racketDelete[j])
	end
	racket.racketDelete = {}
end

function racket.drawAll()
	for i = 1, #racket.rackets do
		racket.draw(i)
	end
end

function racket.controlAll(dt)
	for i = 1, #racket.rackets do
		racket.control(i)
	end
end

function racket.collisionAll()
	for i = 1, #racket.rackets do
		racket.collision(i)
	end
end

function racket.update(i, dt)
	local r = racket.rackets[i]
	-- Caps the x and y velocities if they're positive
	if r.xVelocity > r.xMaxVelocity * 1 then
		r.xVelocity = r.xMaxVelocity * 1
	end
	if r.yVelocity > r.yMaxVelocity * 1 then
		r.yVelocity = r.yMaxVelocity * 1
	end
	-- Caps the x and y velocities if they're negative
	if r.xVelocity < r.xMaxVelocity * -1 then
		r.xVelocity = r.xMaxVelocity * -1
	end
	if r.yVelocity < r.yMaxVelocity * -1 then
		r.yVelocity = r.yMaxVelocity * -1
	end
	-- Updates the position
	r.x = r.x + r.xVelocity * dt
	r.y = r.y + r.yVelocity * dt
	-- Friction
	r.xVelocity = r.xVelocity - (r.xVelocity * r.friction) * dt
	r.yVelocity = r.yVelocity - (r.yVelocity * r.friction) * dt
end

function racket.draw(i)
	local r = racket.rackets[i]
	-- Sets the color
	love.graphics.setColor(255, 255, 255)
	-- Draws the ball
	local drawX = r.x - r.xSize / 2
	local drawY = r.y - r.ySize / 2
	local drawXSize = r.xSize
	local drawYSize = r.ySize
	love.graphics.rectangle("fill", drawX, drawY, drawXSize, drawYSize)
end

function racket.delete(i)
	racket.racketDelete[#racket.racketDelete+1] = i
end

function racket.control(i)
	local r = racket.rackets[i]
	if love.keyboard.isDown(r.controls.up) then
		r.yVelocity = r.yVelocity - r.movementSpeed
	end
	if love.keyboard.isDown(r.controls.down) then
		r.yVelocity = r.yVelocity + r.movementSpeed
	end
end

function racket.collision(i)
	local r = racket.rackets[i]
	for j = 1, #collisionBox.collisionBoxes do
		local c = collisionBox.collisionBoxes[j]
		-- Checks if the collisionBox belongs to the racket
		local belongs = false
		if c.followingType == "racket" and c.followingID == r.id then
			belongs = true
		end
		if belongs == false then
			local dx = 0
			local dy = 0
			local rdx = math.abs(c.x - r.x)
			local rdy = math.abs(c.y - r.y)
			dx = rdx - (r.xSize / 2 + c.xSize / 2)
			dy = rdy - (r.ySize / 2 + c.ySize / 2)
			if dy <= 0 and dx <= 0 then
				-- The collision response will vary, depending on the c.respone variable
				if c.response.ballResponse == "bounce" then
					if dx > dy then
						if r.x < c.x then
							r.x = r.x + dx
						else
							r.x = r.x - dx
						end
						r.xVelocity = 0
					else
						if r.y < c.y then
							r.y = r.y + dy
						else
							r.y = r.y - dy
						end
						r.yVelocity = 0
					end
				end
			end
		end
	end
end