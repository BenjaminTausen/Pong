camera = {}

camera.cameras = {}

camera.cameraDelete = {}

camera.currentCamera = 1

function camera.create(parameters)
	local c = {}
	c.x = parameters.x
	c.y = parameters.y
	c.xZoom = parameters.xZoom
	c.yZoom = parameters.yZoom
	c.xVelocity = parameters.xVelocity
	c.yVelocity = parameters.yVelocity
	c.xMaxVelocity = parameters.xMaxVelocity
	c.yMaxVelocity = parameters.yMaxVelocity
	c.friction = parameters.friction
	c.id = parameters.id
	camera.cameras[#camera.cameras+1] = c
end

function camera.updateAll()
	-- Iterates through the camera.cameraDelete table, and deletes the necessary values
	for j = 1, #camera.cameraDelete do
		table.remove(camera.cameras, camera.cameraDelete[j])
	end
	camera.cameraDelete = {}
end

function camera.update(dt)
	--
end

function camera.delete(i)
	camera.cameraDelete[#camera.cameraDelete+1] = i
end

function camera.scaleTranslate(i)
	for j = 1, #camera.cameras do
		if j == i then
			local c = camera.cameras[i]
			local screenWidth, screenHeight = love.graphics.getDimensions()
			local ingameXResolution = 800
			local ingameYResolution = 600
			love.graphics.scale(screenWidth / ingameXResolution * c.xZoom, screenHeight / ingameYResolution * c.yZoom)
			love.graphics.translate(c.x * -1 + ingameXResolution / (c.xZoom * 2), c.y * -1 + ingameYResolution / (c.yZoom * 2))
		end
	end
end