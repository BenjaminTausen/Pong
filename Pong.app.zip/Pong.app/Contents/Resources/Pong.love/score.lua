score = {winningSide = "NO", winnerParameters = {x = 400, y = 300, xSize = 3, ySize = 3}}

score.scores = {}

score.scoreDelete = {}

function score.create(parameters)
	local s = {}
	s.x = parameters.x
	s.y = parameters.y
	s.xSize = parameters.xSize
	s.ySize = parameters.ySize
	s.score = parameters.score
	s.scoreAmount = parameters.scoreAmount
	s.id = parameters.id
	score.scores[#score.scores+1] = s
end

function score.updateAll()
	for i = 1, #score.scores do
		score.update(i)
	end
	-- Iterates through the score.scoreDelete table, and deletes the necessary values
	for j = 1, #score.scoreDelete do
		table.remove(score.scores, score.scoreDelete[j])
	end
	score.scoreDelete = {}
end

function score.update(i)
	local s = score.scores[i]
	-- Iterates through the scores, to see if any score is higher than the limit
	for j = 1, #s.score do
		if s.score[j] >= s.scoreAmount then
			if j == 1 then
				score.winningSide = "LEFT"
			elseif j == 2 then
				score.winningSide = "RIGHT"
			end
			state.set("win")
		end
	end
end

function score.delete(i)
	score.scoreDelete[#score.scoreDelete+1] = i
end

function score.drawAll()
	for i = 1, #score.scores do
		score.draw(i)
	end
end

function score.draw(i)
	local s = score.scores[i]
	-- Sets the color
	love.graphics.setColor(255, 255, 255)
	-- Draws the score
	local drawString = tostring(s.score[1] .. ":" .. s.score[2])
	local drawX = s.x - (pixelFont:getWidth(drawString) * s.xSize) / 2
	local drawY = s.y
	local drawXSize = s.xSize
	local drawYSize = s.ySize
	love.graphics.printf(drawString, drawX, drawY, 800, "left", 0, drawXSize, drawYSize, 0, 0, 0, 0)
end

function score.increment(parameters)
	local s = score.scores[parameters.i]
	s.score[parameters.side] = s.score[parameters.side] + parameters.amount
end