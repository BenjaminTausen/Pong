require("collisionBox")
require("score")
require("timer")

ball = {}

ball.balls = {}

ball.ballSource = {}

ball.ballSource.ballSources = {}

ball.ballSource.ballSourceDelete = {}

ball.ballDelete = {}

function ball.create(parameters)
	local b = {}
	b.x = parameters.x
	b.y = parameters.y
	b.xSize = parameters.xSize
	b.ySize = parameters.ySize
	b.xVelocity = parameters.xVelocity
	b.yVelocity = parameters.yVelocity
	b.xMaxVelocity = parameters.xMaxVelocity
	b.yMaxVelocity = parameters.yMaxVelocity
	b.friction = parameters.friction
	b.origin = parameters.origin
	b.id = parameters.id
	ball.balls[#ball.balls+1] = b
end

function ball.ballSource.create(parameters)
	local b = {}
	b.x = parameters.x
	b.y = parameters.y
	b.maxBalls = parameters.maxBalls
	b.ballSpeed = parameters.ballSpeed
	b.ballMaxSpeed = parameters.ballMaxSpeed
	b.delay = parameters.delay
	b.timeStamp = 0
	b.id = parameters.id
	ball.ballSource.ballSources[#ball.ballSource.ballSources+1] = b
end

function ball.ballSource.updateAll()
	-- Iterates through the ball.ballSource.ballSourceDelete table, and deletes the necessary values
	for j = 1, #ball.ballSource.ballSourceDelete do
		table.remove(ball.ballSource.ballSources, ball.ballSource.ballSourceDelete[j])
	end
	ball.ballSource.ballSourceDelete = {}
	for i = 1, #ball.ballSource.ballSources do
		ball.ballSource.update(i)
	end
end

function ball.updateAll(dt)
	for i = 1, #ball.balls do
		ball.update(i, dt)
	end
	-- Iterates through the ball.ballDelete table, and deletes the necessary values
	for j = 1, #ball.ballDelete do
		table.remove(ball.balls, ball.ballDelete[j])
	end
	ball.ballDelete = {}
end

function ball.drawAll()
	for i = 1, #ball.balls do
		ball.draw(i)
	end
end

function ball.collisionAll()
	for i = 1, #ball.balls do
		ball.collision(i)
	end
end

function ball.update(i, dt)
	local b = ball.balls[i]
	-- Caps the x and y velocities if they're positive
	if b.xVelocity > b.xMaxVelocity * 1 then
		b.xVelocity = b.xMaxVelocity * 1
	end
	if b.yVelocity > b.yMaxVelocity * 1 then
		b.yVelocity = b.yMaxVelocity * 1
	end
	-- Caps the x and y velocities if they're negative
	if b.xVelocity < b.xMaxVelocity * -1 then
		b.xVelocity = b.xMaxVelocity * -1
	end
	if b.yVelocity < b.yMaxVelocity * -1 then
		b.yVelocity = b.yMaxVelocity * -1
	end
	-- Updates the position
	b.x = b.x + b.xVelocity * dt
	b.y = b.y + b.yVelocity * dt
	-- Checks for collision
	ball.collision(i)
	-- Friction
	b.xVelocity = b.xVelocity - (b.xVelocity * b.friction) * dt
	b.yVelocity = b.yVelocity - (b.yVelocity * b.friction) * dt
end

function ball.draw(i)
	local b = ball.balls[i]
	-- Sets the color
	love.graphics.setColor(255, 255, 255)
	-- Draws the ball
	local drawX = b.x - b.xSize / 2
	local drawY = b.y - b.ySize / 2
	local drawXSize = b.xSize
	local drawYSize = b.ySize
	love.graphics.rectangle("fill", drawX, drawY, drawXSize, drawYSize)
end

function ball.delete(i)
	ball.ballDelete[#ball.ballDelete+1] = i
end

function ball.ballSource.delete(i)
	ball.ballSource.ballSourceDelete[#ball.ballSource.ballSourceDelete+1] = i
end

function ball.collision(i)
	local b = ball.balls[i]
	for j = 1, #collisionBox.collisionBoxes do
		local c = collisionBox.collisionBoxes[j]
		local dx = 0
		local dy = 0
		local bdx = math.abs(c.x - b.x)
		local bdy = math.abs(c.y - b.y)
		dx = bdx - (b.xSize / 2 + c.xSize / 2)
		dy = bdy - (b.ySize / 2 + c.ySize / 2)
		if dy <= 0 and dx <= 0 then
			-- Collision response for the ball
			if c.response.ballResponse == "bounce" then
				if dx > dy then
					if b.x < c.x then
						b.x = b.x + dx
					else
						b.x = b.x - dx
					end
					b.xVelocity = b.xVelocity * -1
				else
					if b.y < c.y then
						b.y = b.y + dy
					else
						b.y = b.y - dy
					end
					b.yVelocity = b.yVelocity * -1
				end
				b.xVelocity = b.xVelocity + c.followingXVel
				b.yVelocity = b.yVelocity + c.followingYVel
				-- Plays the appropriate sound
				sfx.playRandom({sfx.soundEffects.hit1, sfx.soundEffects.hit2})
			end
			if c.response.ballResponse == "kill" then
				ball.delete(i)
				-- Sets the timeStamp variable of the origin ballSource
				ball.ballSource.ballSources[b.origin].timeStamp = timer.timer
				-- Plays the appropriate sound
				sfx.play(sfx.soundEffects.hit3)
			end
			-- Collision response for the score
			if c.response.scoreResponse == "increment" then
				score.increment({i = #score.scores, side = c.response.scoreSide, amount = c.response.scoreAmount})
			end
		end
	end
end

function ball.ballSource.update(i)
	b = ball.ballSource.ballSources[i]
	-- Creates a ball if necessary
	if #ball.balls < b.maxBalls and timer.timer >= b.timeStamp + b.delay then
		-- Calculates the x and y velocities
		local vel = b.ballSpeed
		-- Determines the direction of the ball, and makes sure the direction is preferable
		local dir = love.math.random(0 * 100, 1 * 100) / 100
		if dir < 0.5 then
			dir = love.math.random(0 * 100, 1 * 100) / 100
			if dir < 0.5 then
				dir = love.math.random((math.pi * 1.75) * 10000, (math.pi * 2) * 10000) / 10000
			else
				dir = love.math.random((math.pi * 0) * 10000, (math.pi * 0.25) * 10000) / 10000
			end
		else
			dir = love.math.random((math.pi * 0.75) * 10000, (math.pi * 1.25) * 10000) / 10000
		end
		local xVel = math.cos(dir) * vel
		local yVel = math.sin(dir) * vel
		ball.create({x = 400, y = 300, xSize = 10, ySize = 10, xVelocity = xVel, yVelocity = yVel, xMaxVelocity = b.ballMaxSpeed, yMaxVelocity = b.ballMaxSpeed, friction = 0, origin = i, id = #ball.balls})
	end
end