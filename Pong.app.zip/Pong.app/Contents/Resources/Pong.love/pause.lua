require("state")

pause = {paused = false, pauseControls = {pause = {"p", false}}, pauseDraw = {"PAUSED", 400, 300, 3, 3}}

function pause.pause()
	pause.paused = true
end

function pause.unpause()
	pause.paused = false
end

function pause.controls()
	-- Checks if the pause key is down
	if love.keyboard.isDown(pause.pauseControls.pause[1]) then
		-- Only proceeds if the pause key was not down in the last frame, and if the game state is set to "game"
		if pause.pauseControls.pause[2] == false and state.state == "game" then
			if pause.paused == false then
				pause.pause()
			else
				pause.unpause()
			end
		end
		pause.pauseControls.pause[2] = true
	else
		pause.pauseControls.pause[2] = false
	end
end

function pause.draw()
	if pause.paused == true then
		-- Draws some text, if the game is paused
		local drawString = pause.pauseDraw[1]
		local drawX = pause.pauseDraw[2] - (pixelFont:getWidth(drawString) * pause.pauseDraw[4]) / 2
		local drawY = pause.pauseDraw[3] - (pixelFont:getHeight(drawString) * pause.pauseDraw[5]) / 2
		local drawXSize = pause.pauseDraw[4]
		local drawYSize = pause.pauseDraw[5]
		love.graphics.printf(drawString, drawX, drawY, 800, "left", 0, drawXSize, drawYSize, 0, 0, 0, 0)
	end
end