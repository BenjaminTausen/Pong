require("sfx")

if state == false then
	state = require("state")
end

menu = {}

menu.button = {}

menu.button.buttons = {}

menu.menuDelete = {}

menu.controls = {cursor = {position = 1, controls = {up = "up", down = "down", select = "z", increment = "c", decrement = "x", downLastFrame = false}}}

menu.options = {ballAmount = 1, ballSpeed = 5, racketSize = 5, scoreAmount = 5}

function menu.button.create(parameters)
	local b = {}
	b.x = parameters.x
	b.y = parameters.y
	b.xSize = parameters.xSize
	b.ySize = parameters.ySize
	b.boxColor = parameters.boxColor
	b.text = parameters.text
	b.textXSize = parameters.textXSize
	b.textYSize = parameters.textYSize
	b.sizeIncrease = 1
	b.textColor = parameters.textColor
	b.action = parameters.action
	b.parameters = parameters.parameters
	b.selectable = parameters.selectable
	b.id = parameters.id
	menu.button.buttons[#menu.button.buttons+1] = b
end

function menu.updateAll()
	-- Updates the option variables
	menu.options.update()
	-- Updates all the buttons
	for i = 1, #menu.button.buttons do
		menu.button.update(i)
	end
	-- Iterates through the menu.menuDelete table, and deletes the necessary values
	for j = 1, #menu.menuDelete do
		table.remove(menu.button.buttons, menu.menuDelete[j])
	end
	menu.menuDelete = {}
end

function menu.button.update(i)
	local b = menu.button.buttons[i]
	if menu.controls.cursor.position == i then
		b.sizeIncrease = 1.2
	else
		b.sizeIncrease = 1
	end
end

function menu.button.drawAll()
	for i = 1, #menu.button.buttons do
		menu.button.draw(i)
	end
end

function menu.button.draw(i)
	local b = menu.button.buttons[i]
	-- Sets the color
	love.graphics.setColor(b.boxColor[1], b.boxColor[2], b.boxColor[3])
	-- Draws the box
	local drawX = b.x - (b.xSize * b.sizeIncrease) / 2
	local drawY = b.y - (b.ySize * b.sizeIncrease) / 2
	local drawXSize = (b.xSize * b.sizeIncrease)
	local drawYSize = (b.ySize * b.sizeIncrease)
	love.graphics.rectangle("fill", drawX, drawY, drawXSize, drawYSize)
	-- Sets the color
	love.graphics.setColor(b.textColor[1], b.textColor[2], b.textColor[3])
	-- Draws the text
	local drawString = ""
	if b.parameters.displayParameters == true then
		drawString = b.text .. " : " .. b.parameters.parameterValue
	else
		drawString = b.text
	end
	local drawX = b.x - (pixelFont:getWidth(drawString) * (b.textXSize * b.sizeIncrease)) / 2
	local drawY = b.y - (pixelFont:getHeight(drawString) * (b.textYSize * b.sizeIncrease)) / 2
	local drawXSize = (b.textXSize * b.sizeIncrease)
	local drawYSize = (b.textYSize * b.sizeIncrease)
	love.graphics.printf(drawString, drawX, drawY, b.xSize, "left", 0, drawXSize, drawYSize, 0, 0, 0, 0)
end

function menu.options.update()
	-- Finds the last button, with the action variable set to ballAmount
	for i = 1, #menu.button.buttons do
		local b = menu.button.buttons[i]
		if menu.button.buttons[i].action == "ballAmount" then
			menu.options.ballAmount = b.parameters.parameterValue
		end
	end
	-- Finds the last button, with the action variable set to ballSpeed
	for i = 1, #menu.button.buttons do
		local b = menu.button.buttons[i]
		if menu.button.buttons[i].action == "ballSpeed" then
			menu.options.ballSpeed = b.parameters.parameterValue
		end
	end
	-- Finds the last button, with the action variable set to racketSize
	for i = 1, #menu.button.buttons do
		local b = menu.button.buttons[i]
		if menu.button.buttons[i].action == "racketSize" then
			menu.options.racketSize = b.parameters.parameterValue
		end
	end
	-- Finds the last button, with the action variable set to scoreAmount
	for i = 1, #menu.button.buttons do
		local b = menu.button.buttons[i]
		if menu.button.buttons[i].action == "scoreAmount" then
			menu.options.scoreAmount = b.parameters.parameterValue
		end
	end
	-- Finds the last button, with the action variable set to sfxVolume
	for i = 1, #menu.button.buttons do
		local b = menu.button.buttons[i]
		if menu.button.buttons[i].action == "sfxVolume" then
			sfx.volume = b.parameters.parameterValue
		end
	end
end

function menu.controls.controls()
	for i = 1, #menu.button.buttons do
		local keyPressed = false
		if love.keyboard.isDown(menu.controls.cursor.controls.up) then
			if menu.controls.cursor.controls.downLastFrame == false then
				menu.controls.cursor.move("up")
			end
			keyPressed = true
		end
		if love.keyboard.isDown(menu.controls.cursor.controls.down) then
			if menu.controls.cursor.controls.downLastFrame == false then
				menu.controls.cursor.move("down")
			end
			keyPressed = true
		end
		if love.keyboard.isDown(menu.controls.cursor.controls.select) then
			if menu.controls.cursor.controls.downLastFrame == false then
				menu.controls.cursor.select(menu.controls.cursor.position)
			end
			keyPressed = true
		end
		if love.keyboard.isDown(menu.controls.cursor.controls.increment) then
			if menu.controls.cursor.controls.downLastFrame == false then
				menu.controls.cursor.increment(menu.controls.cursor.position, 1)
			end
			keyPressed = true
		end
		if love.keyboard.isDown(menu.controls.cursor.controls.decrement) then
			if menu.controls.cursor.controls.downLastFrame == false then
				menu.controls.cursor.increment(menu.controls.cursor.position, -1)
			end
			keyPressed = true
		end
		-- If keyPressed is updated to true, that means a key was pressed, and downLastFrame will be updated to true
		if keyPressed == false then
			menu.controls.cursor.controls.downLastFrame = false
		else
			menu.controls.cursor.controls.downLastFrame = true
		end
	end
end

function menu.controls.cursor.increment(i, amount)
	local b = menu.button.buttons[i]
	b.parameters.parameterValue = b.parameters.parameterValue + amount
	-- Checks if the parameterValue exceeds the parameter's limits, and reacts accordingly
	if b.parameters.parameterValue > b.parameters.parameterMax then
		b.parameters.parameterValue = b.parameters.parameterMax
	end
	if b.parameters.parameterValue < b.parameters.parameterMin then
		b.parameters.parameterValue = b.parameters.parameterMin
	end
	-- Plays the appropriate sound
	if amount < 0 then
		sfx.play(sfx.soundEffects.select3)
	else
		sfx.play(sfx.soundEffects.select4)
	end
end

function menu.controls.cursor.move(action)
	if action == "down" then
		-- Finds the closest valid position
		local validPositionFound = false
		while validPositionFound == false do
			-- Increments the value
			menu.controls.cursor.position = menu.controls.cursor.position + 1
			-- Checks if the cursor position is out of bounds
			if menu.controls.cursor.position > #menu.button.buttons then
				menu.controls.cursor.position = 1
			elseif menu.controls.cursor.position < 1 then
				menu.controls.cursor.position = #menu.button.buttons
			end
			if menu.button.buttons[menu.controls.cursor.position].selectable == true then
				validPositionFound = true
			end
		end
		-- Plays the appropriate sound
		sfx.play(sfx.soundEffects.select1)
	end
	if action == "up" then
		-- Finds the closest valid position
		local validPositionFound = false
		while validPositionFound == false do
			-- Decrements the value
			menu.controls.cursor.position = menu.controls.cursor.position - 1
			-- Checks if the cursor position is out of bounds
			if menu.controls.cursor.position > #menu.button.buttons then
				menu.controls.cursor.position = 1
			elseif menu.controls.cursor.position < 1 then
				menu.controls.cursor.position = #menu.button.buttons
			end
			if menu.button.buttons[menu.controls.cursor.position].selectable == true then
				validPositionFound = true
			end
		end
		-- Plays the appropriate sound
		sfx.play(sfx.soundEffects.select1)
	end
	-- Checks if the cursor position is out of bounds
	if menu.controls.cursor.position > #menu.button.buttons then
		menu.controls.cursor.position = 1
	elseif menu.controls.cursor.position < 1 then
		menu.controls.cursor.position = #menu.button.buttons
	end
end

function menu.controls.cursor.select(i)
	local b = menu.button.buttons[i]
	local actionTaken = false
	if b.action == "start" then
		state.set("game")
		actionTaken = true
	end
	if b.action == "main" then
		state.set("main")
		actionTaken = true
	end
	if b.action == "options" then
		state.set("options")
		actionTaken = true
	end
	if b.action == "soundOptions" then
		state.set("soundOptions")
		actionTaken = true
	end
	if b.action == "quit" then
		state.set("quit")
		actionTaken = true
	end
	if actionTaken == true then
		-- Plays the appropriate sound
		sfx.play(sfx.soundEffects.select2)
	end
end

function menu.delete(i)
	menu.menuDelete[#menu.menuDelete+1] = i
end