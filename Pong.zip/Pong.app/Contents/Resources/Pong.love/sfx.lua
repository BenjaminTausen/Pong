sfx = {}

-- Volume goes from 1-10
sfx.volume = 10

sfx.soundEffects = {}

function sfx.load()
	sfx.soundEffects.hit1 = love.audio.newSource("sfx/hit1.wav", "static")
	sfx.soundEffects.hit2 = love.audio.newSource("sfx/hit2.wav", "static")
	sfx.soundEffects.hit3 = love.audio.newSource("sfx/hit3.wav", "static")
	sfx.soundEffects.select1 = love.audio.newSource("sfx/select1.wav", "static")
	sfx.soundEffects.select2 = love.audio.newSource("sfx/select2.wav", "static")
	sfx.soundEffects.select3 = love.audio.newSource("sfx/select3.wav", "static")
	sfx.soundEffects.select4 = love.audio.newSource("sfx/select4.wav", "static")
end

function sfx.play(soundEffect)
	soundEffect:setVolume(sfx.volume * 0.1)
	love.audio.stop(soundEffect)
	love.audio.play(soundEffect)
end

function sfx.playRandom(soundEffects)
	local i = love.math.random(1, #soundEffects)
	sfx.play(soundEffects[i])
end