timer = {}

timer.timer = 0

function timer.update(dt)
	timer.timer = timer.timer + dt
end