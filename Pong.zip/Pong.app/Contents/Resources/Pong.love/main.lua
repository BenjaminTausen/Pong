require("ball")
require("racket")
require("collisionBox")
require("camera")
require("score")
require("pause")
require("menu")
require("state")
require("timer")
require("sfx")

function love.load()
	-- Creates and sets the font
	pixelFont = love.graphics.newFont("munro.ttf", 20)
	love.graphics.setFont(pixelFont)
	pixelFont:setFilter("nearest", "nearest")
	-- Loads sound effects
	sfx.load()
	-- Sets the game state
	state.set("main")
end

function love.update(dt)
	pause.controls()
	-- Checks if the game is paused
	if pause.paused == false then
		racket.controlAll(dt)
		ball.updateAll(dt)
		racket.updateAll(dt)
		collisionBox.updateAll()
		racket.collisionAll()
		menu.controls.controls()
		ball.ballSource.updateAll()
		menu.updateAll()
		camera.updateAll()
		score.updateAll()
	end
	timer.update(dt)
end

function love.draw()
	camera.scaleTranslate(camera.currentCamera)
	ball.drawAll()
	racket.drawAll()
	score.drawAll()
	menu.button.drawAll()
	pause.draw()
end