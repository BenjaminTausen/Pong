if racket == false then
	racket = require("racket")
end

collisionBox = {}

collisionBox.collisionBoxes = {}

collisionBox.collisionBoxDelete = {}

function collisionBox.create(parameters)
	local c = {}
	c.x = parameters.x
	c.y = parameters.y
	c.xSize = parameters.xSize
	c.ySize = parameters.ySize
	c.static = parameters.static
	c.followingType = parameters.followingType
	c.followingID = parameters.followingID
	c.followingXVel = 0
	c.followingYVel = 0
	c.response = parameters.response
	collisionBox.collisionBoxes[#collisionBox.collisionBoxes+1] = c
end

function collisionBox.updateAll()
	for i = 1, #collisionBox.collisionBoxes do
		collisionBox.update(i)
	end
	-- Iterates through the collisionBox.collisionBoxDelete table, and deletes the necessary values
	for j = 1, #collisionBox.collisionBoxDelete do
		table.remove(collisionBox.collisionBoxes, collisionBox.collisionBoxDelete[j])
	end
	collisionBox.collisionBoxDelete = {}
end

function collisionBox.update(i)
	local c = collisionBox.collisionBoxes[i]
	-- Updates the collisionBox's position
	if c.static == false then
		if c.followingType == "racket" then
			for j = 1, #racket.rackets do
				local r = racket.rackets[j]
				if r.id == c.followingID then
					c.x = r.x
					c.y = r.y
					c.followingXVel = r.xVelocity
					c.followingYVel = r.yVelocity
				end
			end
		end
	end
end

function collisionBox.delete(i)
	collisionBox.collisionBoxDelete[#collisionBox.collisionBoxDelete+1] = i
end