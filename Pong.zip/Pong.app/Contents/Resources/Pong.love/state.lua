require("camera")
require("ball")
require("racket")
require("collisionBox")
require("score")
require("sfx")

if menu == false then
	menu = require("menu")
end

state = {state = nil}

function state.set(newState)
	state.state = newState
	if newState == "game" then
		-- Deletes the cameras
		for i = 1, #camera.cameras do
			camera.delete(1)
		end
		-- Deletes the menu buttons
		for j = 1, #menu.button.buttons do
			menu.delete(1)
		end
		-- Creates the camera
		camera.create({x = 400, y = 300, xZoom = 1, yZoom = 1, xVelocity = 0, yVelocity = 0, xMaxVelocity = 650, yMaxVelocity = 650, friction = 8, id = 1})
		-- Creates the rackets
		racket.create({x = 100, y = 300, xSize = 25, ySize = menu.options.racketSize * 20, xVelocity = 0, yVelocity = 0, xMaxVelocity = 700, yMaxVelocity = 800, friction = 8, movementSpeed = 250, controls = {up = "w", down = "s"}, id = 1})
		racket.create({x = 700, y = 300, xSize = 25, ySize = menu.options.racketSize * 20, xVelocity = 0, yVelocity = 0, xMaxVelocity = 700, yMaxVelocity = 800, friction = 8, movementSpeed = 250, controls = {up = "up", down = "down"}, id = 2})
		-- Creates the rackets' collisionBoxes
		collisionBox.create({x = 0, y = 0, xSize = 25, ySize = menu.options.racketSize * 20, static = false, followingType = "racket", followingID = 1, response = {ballResponse = "bounce", scoreResponse = nil, scoreSide = nil, scoreAmount = nil}})
		collisionBox.create({x = 0, y = 0, xSize = 25, ySize = menu.options.racketSize * 20, static = false, followingType = "racket", followingID = 2, response = {ballResponse = "bounce", scoreResponse = nil, scoreSide = nil, scoreAmount = nil}})
		-- Creates the top and bottom borders
		collisionBox.create({x = 400, y = -25, xSize = 850, ySize = 50, static = true, followingType = "", followingID = nil, response = {ballResponse = "bounce", scoreResponse = nil, scoreSide = nil, scoreAmount = nil}})
		collisionBox.create({x = 400, y = 625, xSize = 850, ySize = 50, static = true, followingType = "", followingID = nil, response = {ballResponse = "bounce", scoreResponse = nil, scoreSide = nil, scoreAmount = nil}})
		-- Creates the right and left borders
		collisionBox.create({x = -25, y = 300, xSize = 50, ySize = 650, static = true, followingType = "", followingID = nil, response = {ballResponse = "kill", scoreResponse = "increment", scoreSide = 2, scoreAmount = 1}})
		collisionBox.create({x = 825, y = 300, xSize = 50, ySize = 650, static = true, followingType = "", followingID = nil, response = {ballResponse = "kill", scoreResponse = "increment", scoreSide = 1, scoreAmount = 1}})
		-- Creates the ball source
		ball.ballSource.create({x = 400, y = 300, maxBalls = menu.options.ballAmount, ballSpeed = menu.options.ballSpeed * 80, ballMaxSpeed = (menu.options.ballSpeed * 80) * 1.5, delay = 1, id = 1})
		-- Creates the score
		score.create({x = 400, y = 50, xSize = 3, ySize = 3, score = {0, 0}, scoreAmount = menu.options.scoreAmount, id = 1})
	end
	if newState == "main" then
		-- Deletes the cameras
		for i = 1, #camera.cameras do
			camera.delete(1)
		end
		-- Resets the cursor position
		menu.controls.cursor.position = 1
		-- Deletes the menu buttons
		for j = 1, #menu.button.buttons do
			menu.delete(1)
		end
		-- Creates the camera
		camera.create({x = 400, y = 300, xZoom = 1, yZoom = 1, xVelocity = 0, yVelocity = 0, xMaxVelocity = 650, yMaxVelocity = 650, friction = 8, id = 1})
		-- Creates the options menu
		menu.button.create({x = 400, y = 200, xSize = 200, ySize = 75, boxColor = {0, 0, 0}, text = "Start Game", textXSize = 2, textYSize = 2, textColor = {255, 255, 255}, action = "start", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = true, id = 1})
		menu.button.create({x = 400, y = 300, xSize = 125, ySize = 75, boxColor = {0, 0, 0}, text = "Options", textXSize = 2, textYSize = 2, textColor = {255, 255, 255}, action = "options", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = true, id = 2})
		menu.button.create({x = 400, y = 400, xSize = 175, ySize = 75, boxColor = {0, 0, 0}, text = "Quit Game", textXSize = 2, textYSize = 2, textColor = {255, 255, 255}, action = "quit", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = true, id = 3})
		menu.button.create({x = 400, y = 585, xSize = 600, ySize = 75, boxColor = {0, 0, 0}, text = "All rights reserved to Benjamin Tausen a Lava", textXSize = 0.75, textYSize = 0.75, textColor = {255, 255, 255}, action = "", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = false, id = 4})
		-- Controls
		menu.button.create({x = 75, y = 25, xSize = 250, ySize = 15, boxColor = {0, 0, 0}, text = "Controls", textXSize = 1, textYSize = 1, textColor = {255, 255, 255}, action = "", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = false, id = 5})
		menu.button.create({x = 75, y = 50, xSize = 250, ySize = 15, boxColor = {0, 0, 0}, text = "Select : Z", textXSize = 0.75, textYSize = 0.75, textColor = {255, 255, 255}, action = "", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = false, id = 6})
		menu.button.create({x = 75, y = 75, xSize = 250, ySize = 15, boxColor = {0, 0, 0}, text = "Increase : C", textXSize = 0.75, textYSize = 0.75, textColor = {255, 255, 255}, action = "", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = false, id = 7})
		menu.button.create({x = 75, y = 100, xSize = 250, ySize = 15, boxColor = {0, 0, 0}, text = "Decrease : X", textXSize = 0.75, textYSize = 0.75, textColor = {255, 255, 255}, action = "", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = false, id = 8})
		menu.button.create({x = 75, y = 125, xSize = 300, ySize = 15, boxColor = {0, 0, 0}, text = "Pause : P", textXSize = 0.75, textYSize = 0.75, textColor = {255, 255, 255}, action = "", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = false, id = 9})
		menu.button.create({x = 75, y = 150, xSize = 250, ySize = 15, boxColor = {0, 0, 0}, text = "Up : Up Arrow", textXSize = 0.75, textYSize = 0.75, textColor = {255, 255, 255}, action = "", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = false, id = 10})
		menu.button.create({x = 75, y = 175, xSize = 300, ySize = 15, boxColor = {0, 0, 0}, text = "Down : Down Arrow", textXSize = 0.75, textYSize = 0.75, textColor = {255, 255, 255}, action = "", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = false, id = 11})
	end
	if newState == "options" then
		-- Deletes the cameras
		for i = 1, #camera.cameras do
			camera.delete(1)
		end
		-- Deletes the menu buttons
		for j = 1, #menu.button.buttons do
			menu.delete(1)
		end
		-- Resets the cursor position
		menu.controls.cursor.position = 1
		-- Creates the camera
		camera.create({x = 400, y = 300, xZoom = 1, yZoom = 1, xVelocity = 0, yVelocity = 0, xMaxVelocity = 650, yMaxVelocity = 650, friction = 8, id = 1})
		-- Creates the options menu
		menu.button.create({x = 400, y = 50, xSize = 250, ySize = 75, boxColor = {0, 0, 0}, text = "Ball Amount", textXSize = 2, textYSize = 2, textColor = {255, 255, 255}, action = "ballAmount", parameters = {parameterValue = menu.options.ballAmount, parameterMax = 4, parameterMin = 1, displayParameters = true}, selectable = true, id = 1})
		menu.button.create({x = 400, y = 150, xSize = 250, ySize = 75, boxColor = {0, 0, 0}, text = "Ball Speed", textXSize = 2, textYSize = 2, textColor = {255, 255, 255}, action = "ballSpeed", parameters = {parameterValue = menu.options.ballSpeed, parameterMax = 10, parameterMin = 1, displayParameters = true}, selectable = true, id = 2})
		menu.button.create({x = 400, y = 250, xSize = 250, ySize = 75, boxColor = {0, 0, 0}, text = "Racket Size", textXSize = 2, textYSize = 2, textColor = {255, 255, 255}, action = "racketSize", parameters = {parameterValue = menu.options.racketSize, parameterMax = 10, parameterMin = 1, displayParameters = true}, selectable = true, id = 3})
		menu.button.create({x = 400, y = 350, xSize = 250, ySize = 75, boxColor = {0, 0, 0}, text = "Game Length", textXSize = 2, textYSize = 2, textColor = {255, 255, 255}, action = "scoreAmount", parameters = {parameterValue = menu.options.scoreAmount, parameterMax = 100, parameterMin = 1, displayParameters = true}, selectable = true, id = 4})
		menu.button.create({x = 400, y = 450, xSize = 800, ySize = 75, boxColor = {0, 0, 0}, text = "Sound Volume", textXSize = 2, textYSize = 2, textColor = {255, 255, 255}, action = "sfxVolume", parameters = {parameterValue = sfx.volume, parameterMax = 10, parameterMin = 0, displayParameters = true}, selectable = true, id = 1})
		menu.button.create({x = 400, y = 550, xSize = 250, ySize = 75, boxColor = {0, 0, 0}, text = "Back", textXSize = 2, textYSize = 2, textColor = {255, 255, 255}, action = "main", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = true, id = 6})
	end
	if newState == "win" then
		-- Deletes the ballSources
		for i = 1, #ball.ballSource.ballSources do
			ball.ballSource.delete(1)
		end
		-- Deletes the balls
		for i = 1, #ball.balls do
			ball.delete(1)
		end
		-- Deletes the rackets
		for i = 1, #racket.rackets do
			racket.delete(1)
		end
		-- Deletes the collisionBoxes
		for i = 1, #collisionBox.collisionBoxes do
			collisionBox.delete(1)
		end
		-- Deletes the scores
		for i = 1, #score.scores do
			score.delete(1)
		end
		-- Deletes the cameras
		for i = 1, #camera.cameras do
			camera.delete(1)
		end
		-- Deletes the menu buttons
		for j = 1, #menu.button.buttons do
			menu.delete(1)
		end
		-- Resets the cursor position
		menu.controls.cursor.position = 2
		-- Creates the camera
		camera.create({x = 400, y = 300, xZoom = 1, yZoom = 1, xVelocity = 0, yVelocity = 0, xMaxVelocity = 650, yMaxVelocity = 650, friction = 8, id = 1})
		-- Creates the return button
		menu.button.create({x = 400, y = 250, xSize = 250, ySize = 75, boxColor = {0, 0, 0}, text = tostring(score.winningSide .. " SIDE WINS"), textXSize = 4, textYSize = 4, textColor = {255, 255, 255}, action = "", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = false, id = 1})
		menu.button.create({x = 400, y = 350, xSize = 250, ySize = 75, boxColor = {0, 0, 0}, text = "Return to main menu", textXSize = 2, textYSize = 2, textColor = {255, 255, 255}, action = "main", parameters = {parameterValue = 1, parameterMax = 1, parameterMin = 1, displayParameters = false}, selectable = true, id = 2})
	end
	if newState == "quit" then
		-- Quits the game
		love.event.quit()
	end
end